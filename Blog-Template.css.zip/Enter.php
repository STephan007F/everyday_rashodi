<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    
    <meta charset="utf-8">
    
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Enter.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>
    
  </head>



  <body class="u-body">

  

    <section class="u-clearfix u-palette-5-light-2 u-section-1" id="sec-53c2">
      <!--Заголовок-->
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-default u-text-1">Поле входа в аккаунт</h1>
        <div class="u-form u-form-1">
          <!--Form Enter-->
          <form method = "POST" action = "auth.php" >
            <!--Email-->
            <div class="u-form-email u-form-group">
              <label for="email-9a60" class="u-form-control-hidden u-label"></label>
              <input type="email" placeholder="Введите Ваш email адрес" id="email-9a60" name="email" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white" required="">
            </div>
            <!--Password-->
            <div class="u-form-group u-form-group-2">
              <label for="text-8209" class="u-form-control-hidden u-label"></label>
              <input type="password" placeholder="Введите пароль" id="text-8209" name="pass" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white">
            </div>
            <!--Button-->
            <div class="u-align-left u-form-group u-form-submit">
              <a href="#" class="u-btn u-btn-submit u-button-style">Отправить</a>
              <input type="submit" value="submit" class="u-form-control-hidden">
            </div>
            

        </div>
      </div>
    </section>
    
    <?php  include 'footer.php';   ?>
    
  </body>
</html>