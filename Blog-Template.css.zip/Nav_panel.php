<body class="u-body">

<!--   NAV Панелька   -->
    <ul class="nav nav-pills">
      <li class="nav-item">
        <a class="nav-link" aria-current="page" href="index.php">Ваши доходы и расходы</a> 
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="add_give.php">Внесение расходов</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="account.php">Аккаунт</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="earned.php">Добавление доходов</a>
      </li>
      
      </ul>


      
<?php



?>