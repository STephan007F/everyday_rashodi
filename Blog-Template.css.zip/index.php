<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    
    <meta charset="utf-8">
    
    <title>Index</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Index.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>
  </head>


  <body data-home-page="Index.html" data-home-page-title="Index" class="u-body">

<?php  
if($_COOKIE['user'] == ''): ?>

    <section class="u-clearfix u-palette-5-light-2 u-section-1" id="sec-944b">
      <div class="u-clearfix u-sheet u-sheet-1">
        <!--Заголовок-->
        <h1 class="u-text u-text-default u-text-1">Выберите действие</h1>
        <!--  Enter to account  -->
        <a href="Enter.php" class="u-active-none u-border-2 u-border-active-palette-2-dark-1 u-border-hover-palette-2-base u-border-palette-1-base u-btn u-button-style u-hover-none u-none u-text-hover-palette-2-base u-text-palette-1-base u-btn-1">
          Войти в существующий акаунт
        </a>
        
        <!--Registration-->
        <a href="Registration.php" class="u-active-none u-border-2 u-border-palette-1-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-radius-0 u-btn-2">
          Зарегистрироваться и создать новый аккаунт
        </a>
        <!--Подписи к Ссылкам-->
        <p class="u-text u-text-2">Войти в существующий аккаунт. Подходит для тех кто уже зарегистрирован</p>
        <p class="u-text u-text-3">Создать новый аккуант. Подходит для новый пользователей</p>
      </div>
    </section>


    <?php   else:    ?>

<?php    include 'Nav_panel.php';   ?>




<h1>
  Фильтр по категориям и времени
</h1>
<form action="filter.php" method="POST" style="padding: 10px; border: solid 5px blue">

<!-- Тут у нас категория  -->
<p>
      Выберите какие категории надо показать (не выбирайте ничего если надо показать все)
</p>

<div class="form-check">
  <input class="form-check-input"  name="kat[]" type="checkbox" value="alcogol" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Алкоголь
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" name="kat[]" type="checkbox" value="taxi" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Такси
  </label>
</div>

<div class="form-check">
  <input class="form-check-input"  name="kat[]" type="checkbox" value="food" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Еда
  </label>
</div>

<div class="form-check">
  <input class="form-check-input"  name="kat[]" type="checkbox" value="transport" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Транспорт
  </label>
</div>

<div class="form-check">
  <input class="form-check-input"  name="kat[]" type="checkbox" value="cure" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Лекарства
  </label>
</div>

<div class="form-check">
  <input class="form-check-input"  name="kat[]" type="checkbox" value="cloth" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Одежда
  </label>
</div>

<br>

<div class="container">
  <div class="row align-items-start">
    <div class="col">
      Введите дату с котором начинаем поиск <br>
      <input type="date" placeholder="Дата в формате XX.XX.XXXX"  name="data-1">
    </div>
    <div class="col">
      Введите конечную дату <br>
      <input type="date" placeholder="Дата в формате XX.XX.XXXX"  name="data-2">
    </div>
  </div>
</div>

<div class="u-align-left u-form-group u-form-submit">
  <a href="#" class="u-btn u-btn-submit u-button-style">Отфильтровать</a>
  <input type="submit" value="submit" class="u-form-control-hidden">
</div>

</form>



<!--
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>
    -->

<section class="u-clearfix u-palette-1-light-2 u-section-1" id="sec-3eba">

<?php
        
  $host = 'localhost'; //вот переменные которые необходимы для выполнения подключения 
  $db = 'f0636710_finanses_enter';
  $user = 'f0636710_finanse_user';
  $passwor = 'H0vv$t0$hack';
        
  $mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем

  if($mysql->connect_error)
  {
    die("Connection failed: " . $mysql->connect_error);
  }

  $auth = $_COOKIE['user'];//надо для обхода защиты кавычек   

//используем ф-ию query, она принимает любой запрос на языке БД mysql
$result = $mysql->query("SELECT * FROM `$auth`"); //Это говорит нам следующее
//"Выбери из колонки lost_massiv которая из таблицы users ГДЕ email = Авторизованному пользователю

if($result === FALSE)
{
  echo "плохо: " . $mysql->error;
  exit();
}


while ($array = mysqli_fetch_array($result)) {
  

  //echo "{$array['summa']}: {$array['kategory']}: {$array['day_buyed']}: рублей<br>";

  $summa = $array['summa'];

  switch($array['kategory'])
  {
    case "alcogol":
    $kategory = "Алкоголь";
    break;

    case "taxi":
      $kategory = "Такси";
      break;

    case "food":
      $kategory = "Еда";
      break;

    case "transport":
      $kategory = "Транспорт";
      break;

    case "cure":
      $kategory = "Лекарства";
      break;

    case "cloth":
        $kategory = "Одежда";
        break;

  }

  $year = $array['day_buyed'][0] . $array['day_buyed'][1] . $array['day_buyed'][2] . $array['day_buyed'][3];
  $mes = $array['day_buyed'][5] . $array['day_buyed'][6];
  $day = $array['day_buyed'][8] . $array['day_buyed'][9];

  echo "
  <div class='u-align-left u-clearfix u-sheet u-sheet-1'>
      <div class='container'>
        <div class='row'>";

if($array['type'] == 'lost' || $array['type'] == '')
{
  echo "
        <div class='col-md-4 col-12' style='border: solid 5px black'>";
  
  
    echo "
    <div class='row'>
    <div class='col-12'>
    ";
  
    echo "<h1 class='display-6' style='color: red;'>$summa  руб.</h1> </div><br>";
  
    echo "<div class='col-md-8 col-sm-12'><p>потрачены на: </p><h2 style='color: blue;'>$kategory</h2></div></div>";
  
    echo "<p>Дата покупки: <font color='green '>$day.$mes.$year</font></p>";
  
    echo "</div></div></div>";
} else
{
  echo "
        <div class='col-md-4 col-12' style='border: solid 5px red'>";

  
    echo "
    <div class='row'>
    <div class='col-md-4 col-12'>
    ";
  
    echo "<h1 class='display-6' style='color: red;'>$summa  руб.</h1> </div>";
  
    echo "<div class='col-md-8 col-8'><h2 style='color: green;'>ДОХОД</h2></div></div>";
  
    echo "<p>Дата покупки: <font color='green '>$day.$mes.$year</font></p>";
  
    echo "</div></div></div>";
}

  
}

echo "</div></div></div>";

?>
      </div>
    </section>
      
<?php    endif;   ?>

    <!--Footer-->
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d8bc"><div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <p class="u-text u-text-default u-text-1">Проект "Контроль повседневных расходов"</p>
      </div>
    </footer>
    

  </body>
</html>