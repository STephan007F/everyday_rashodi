<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta charset="utf-8">
    <title>add_give</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
    <link rel="stylesheet" href="add_give.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>
  </head>

  <body class="u-body">


    <?php  include 'Nav_panel.php';  ?>


    <section class="u-clearfix u-palette-3-light-2 u-section-1" id="sec-656e">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-text u-text-default u-text-1">Добавление доходов</h2>
        <div class="u-form u-form-1">
          <form action="earn_obr.php" method="POST" style="padding: 10px;">

            <div class="u-form-group u-form-group-1">
              <label for="text-137e" class="u-label">Введите сумму заработанных денег</label>
              <input type="text" placeholder="Сумма потраченных средств" id="text-137e" name="sum" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white">
            </div>

            <div class="u-form-group u-form-group-3">
              <label for="text-db6a" class="u-label">Введите дату</label>
              <input type="date" placeholder="Дата в формате XX.XX.XXXX" id="text-db6a" name="data" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white">
            </div>
            <div class="u-align-left u-form-group u-form-submit">
              <a href="#" class="u-btn u-btn-submit u-button-style">Отправить</a>
              <input type="submit" value="submit" class="u-form-control-hidden">
            </div>

          </form>
        </div>
      </div>
    </section>
    
    <?php  include 'footer.php';   ?>

    
  </body>
</html>