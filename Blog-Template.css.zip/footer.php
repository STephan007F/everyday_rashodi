<!--Footer-->
<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d8bc"><div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <p class="u-text u-text-default u-text-1">Проект "Контроль повседневных расходов"</p>
      </div>
    </footer>