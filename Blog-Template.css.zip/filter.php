

<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    
    <meta charset="utf-8">
    
    <title>Filter</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Index.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>
  </head>

  <body>


  <?php    include 'Nav_panel.php';   ?>

  <?php

echo "<h2>Результат работы фильтра</h2>";

$kat = $_POST['kat'];
$data1 = $_POST['data-1'];
$data2 = $_POST['data-2'];



$kat_empty = 0; $data1_empty = 0; $data2_empty = 0;

if($kat == '')
{
    $kat_empty = 1;
}

if($data1 == '')
{
    $data1_empty = 1;
}

if($data2 == '')
{
    $data2_empty = 1;
}

  $host = 'localhost'; //вот переменные которые необходимы для выполнения подключения 
  $db = 'f0636710_finanses_enter';
  $user = 'f0636710_finanse_user';
  $passwor = 'H0vv$t0$hack';
        
  $mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем

  if($mysql->connect_error)
  {
    die("Connection failed: " . $mysql->connect_error);
  }

  $auth = $_COOKIE['user'];//надо для обхода защиты кавычек   

//используем ф-ию query, она принимает любой запрос на языке БД mysql
$result = $mysql->query("SELECT * FROM `$auth`"); //Это говорит нам следующее
//"Выбери из колонки lost_massiv которая из таблицы users ГДЕ email = Авторизованному пользователю

if($result === FALSE)
{
  echo "плохо: " . $mysql->error;
  exit();
}

echo "
  <div class='u-align-left u-clearfix u-sheet u-sheet-1'>
      <div class='container'>
        <div class='row'>
  ";

while ($array = mysqli_fetch_array($result)) 
{

  

    //echo "{$array['summa']}: {$array['kategory']}: {$array['day_buyed']}: рублей<br>";
  
    $summa = $array['summa'];
  
    switch($array['kategory'])
    {
      case "alcogol":
      $kategory = "Алкоголь";
      break;
  
      case "taxi":
        $kategory = "Такси";
        break;
  
      case "food":
        $kategory = "Еда";
        break;
  
      case "transport":
        $kategory = "Транспорт";
        break;
  
      case "cure":
        $kategory = "Лекарства";
        break;
  
      case "cloth":
          $kategory = "Одежда";
          break;
  
    }

    $year = $array['day_buyed'][0] . $array['day_buyed'][1] . $array['day_buyed'][2] . $array['day_buyed'][3];
    $mes = $array['day_buyed'][5] . $array['day_buyed'][6];
    $day = $array['day_buyed'][8] . $array['day_buyed'][9];
  
  if($kat_empty == 1)
  {
    $kategory =$kat;
  }
  if($data1_empty == 1)
  {
    $year = $year1; $mes = $mes1; $day = $day1;
  }
  if($data2_empty == 1)
  {
    $year = $year2; $mes = $mes2; $day = $day2;
  }

  for($i = 0; $i < count($kat); $i++)
  {

    switch($kat[$i])
    {
      case "alcogol":
      $kat[$i] = "Алкоголь";
      break;

      case "taxi":
        $kat[$i] = "Такси";
        break;

      case "food":
        $kat[$i] = "Еда";
        break;

      case "transport":
        $kat[$i] = "Транспорт";
        break;

      case "cure":
        $kat[$i] = "Лекарства";
        break;

      case "cloth":
          $kat[$i] = "Одежда";
          break;

    }


    if($data_time >= $data_time1 && $data_time <= $data_time2 && $kat[$i] == $kategory)
    {
      echo "
        <div class='col-md-4 col-12' style='border: solid 5px black'";
        echo "
          <div class='row'>
          <div class='col-md-4 col-12'>
          ";

          echo "<h1 class='display-6' style='color: red;'>$summa  руб.</h1> </div>";

          echo "<div class='col-md-8 col-8'><p>потрачены на: </p><h2 style='color: blue;'>$kategory</h2></div>";

          echo "<p>Дата покупки: <font color='green '>$day.$mes.$year</font></p></div>";

          echo "</div></div>";
    }


  }
  echo "</div></div></div>";
} 


include 'footer.php';

?>

  </body>
</html>