<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    
    <meta charset="utf-8">
    
    <title>new_account</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="new_account.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>
    
  </head>

  <body class="u-body">
  <?php  include 'Nav_panel.php';  ?>

  <?php
    $email = $_POST['email'];
    $get_password = $_POST['password'];
    $get_password_access = $_POST['password_access'];

    if($get_password === $get_password_access)
    {
        $serername = "localhost";
        $username = "finanse_user";
        $password = "H0vv_t0_hack";
        $dbname = "users";
        //создаем подключение
        $conn = new mysqli($servername, $username, $password, $dbname);

        //проверяем подключение
        if($conn->connect_error)
        {
          die("Connection failed: " . $conn->connect_error);
        }

        $sql = "INSERT INTO all_users (email, pass)
        VALUES ('$email', '$get_password')";

        if($conn->query($sql) === TRUE)
        {
          
        } else
        {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }

        
    }
    else
    {
      //моменталка на страницу где ошибка
    }
?>

    <section class="u-clearfix u-palette-1-light-2 u-section-1" id="sec-3eba">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-default u-text-1">Ваш новый аккаунт создан!</h1>
        <h3 class="u-text u-text-default u-text-2">Ваш логин: <?php echo $email ?><br>
          <br>Ваш пароль: <?php  echo $get_password ?><br> <br>
        Очень сильно советуем ва запомнить эти данные! Ведь изменить их нельзя.
        </h3> 
        
        <a href="account.php" class="u-active-none u-border-2 u-border-palette-1-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-radius-0 u-btn-1">Перейти к основному функционалу приложения!</a>
      </div>
    </section>
    
    
    <?php  include 'footer.php';   ?>

  </body>

  <?php //закрываем подключение
        $conn->close(); ?>
</html>