<?php

$sum =  filter_var(trim($_POST['sum']),
FILTER_SANITIZE_STRING);

$kat = filter_var(trim($_POST['kategory']),
FILTER_SANITIZE_STRING);

$data = $_POST['data'];

$auth = $_COOKIE['user'];//надо для обхода защиты кавычек  


if($sum == 0 || $data == '')
{
    echo "Не верные даннные!!!";
    exit();
}



$host = 'localhost'; //вот переменные которые необходимы для выполнения подключения
$db = 'f0636710_finanses_enter';
$user = 'f0636710_finanse_user';
$passwor = 'H0vv$t0$hack';

$mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем

   

if($mysql->connect_error){
    die("Connection failed: " . $mysql->connect_error);
}

$mysql->query("INSERT INTO `$auth` (`type`, `summa`, `kategory`, `day_buyed`) 
VALUES ('lost','$sum', '$kat', '$data')");



$mysql->close();

header('Location: /index.php'); //отправляем пользователя на страницу с карточками

?>