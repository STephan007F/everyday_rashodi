<?php

    $email = $_GET['email'];
    $password = $_GET['password'];
    $password_access = $_GET['password_access'];

    if($password == $password_access)
    {
        $db_host = "localhost"; 
        $db_user = "finanse_user"; // Логин БД
        $db_password = "H0vv_t0_hack"; // Пароль БД
        $db_base = 'users'; // Имя БД
        $db_table = "all_users"; // Имя Таблицы БД
        try
        {
            // Подключение к базе данных
        $db = new PDO("mysql:host=$db_host;dbname=$db_base", $db_user, $db_password);
        // Устанавливаем корректную кодировку
        $db->exec("set names utf8");
        // Собираем данные для запроса
        $data = array( 'name' => $name, 'text' => $text ); 
        // Подготавливаем SQL-запрос
        $query = $db->prepare("INSERT INTO $db_table (name, text) values (:name, :text)");
        // Выполняем запрос с данными
        $query->execute($data);
        // Запишим в переменую, что запрос отрабтал
        $result = true;
        }
    catch(PDOException $e)
        {
        // Если есть ошибка соединения или выполнения запроса, выводим её
        
        print "Ошибка!: " . $e->getMessage() . "<br/>";
        }   
    }
    else 
    {
        
    }

    

?>