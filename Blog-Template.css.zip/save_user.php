<?php 


if (isset($_POST['email'])) { $email = $_POST['email']; if ($email == '') { unset($email);} } 
//заносим введенный пользователем логин в переменную $email, если он пустой, то уничтожаем переменную

    if (isset($_POST['pass'])) { $pass=$_POST['pass']; if ($pass =='') { unset($pass);} }
    //заносим введенный пользователем пароль в переменную $pass, если он пустой, то уничтожаем переменную

 if (empty($email) || empty($pass)) //если пользователь не ввел логин или пароль, то выдаем ошибку и останавливаем скрипт
    {
    exit ("Вы ввели не всю информацию, вернитесь назад и заполните все поля!");
    }

    //если логин и пароль введены, то обрабатываем их, чтобы теги и скрипты не работали, мало ли что люди могут ввести
    $email = stripslashes($email);
    $email = htmlspecialchars($email);
 $pass = stripslashes($pass);
    $pass = htmlspecialchars($pass);

 //удаляем лишние пробелы
    $email = trim($email);
    $pass = trim($pass);

 // подключаемся к базе
    include ("db.php"); // файл bd.php должен быть в той же папке, что и все остальные, если это не так, то просто измените путь 
 // проверка на существование пользователя с таким же логином

    $result = mysqli_query("SELECT id FROM users WHERE email='$email'", $db);
    $myrow = mysql_fetch_array($result);
    if (!empty($myrow['id'])) {
    exit ("Извините, введённый вами логин уже зарегистрирован. Введите другой логин.");
    }
 // если такого нет, то сохраняем данные
    $result2 = mysqli_query ("INSERT INTO users (email,pass) VALUES('$email','$pass')", $db);
    // Проверяем, есть ли ошибки
    if ($result2=='TRUE')
    {
    echo "Вы успешно зарегистрированы! Теперь вы можете зайти на сайт. <a href='Enter.php'>Войти</a>";
    }
 else {
    echo "Ошибка!"; }


?>