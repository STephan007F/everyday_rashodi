<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    
    <meta charset="utf-8">
    
    
    <title>already_given</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="account.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Pryazha"
}</script>

  </head>

  <body class="u-body">

  <?php  include 'Nav_panel.php';  ?>

  <?php
  
  $host = 'localhost'; //вот переменные которые необходимы для выполнения подключения
$db = 'f0636710_finanses_enter';
$user = 'f0636710_finanse_user';
$passwor = 'H0vv$t0$hack';

$mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем

if($mysql->connect_error)
{
    die("Connection failed: " . $mysql->connect_error);
}  
$auth = $_COOKIE['user'];//надо для обхода защиты кавычек   

//используем ф-ию query, она принимает любой запрос на языке БД mysql
$result = $mysql->query("SELECT * FROM `$auth` WHERE `type`='lost'"); //Это говорит нам следующее
//"Выбери из колонки lost_massiv которая из таблицы users ГДЕ email = Авторизованному пользователю

if($result === FALSE)
{
  echo "плохо: " . $mysql->error;
  exit();
}
$summa = 0;
while ($array = mysqli_fetch_array($result)) {
  $summa += $array['summa'];}
  
    ?>


    <section class="u-clearfix u-palette-1-light-2 u-section-1" id="sec-3eba">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-default u-text-1">Ваш аккаунт</h1>
        <h3 class="u-text u-text-default u-text-2"><?php echo $_COOKIE['user']; ?></h3>
        <p>Вы потратили в сумме <?php echo $summa . " руб.";?></p>

        <?php
        
        //используем ф-ию query, она принимает любой запрос на языке БД mysql
$result = $mysql->query("SELECT * FROM `$auth` WHERE `type`='earned'"); //Это говорит нам следующее
//"Выбери из колонки lost_massiv которая из таблицы users ГДЕ email = Авторизованному пользователю

if($result === FALSE)
{
  echo "плохо: " . $mysql->error;
  exit();
}
$summ = 0;
while ($array = mysqli_fetch_array($result)) {
  $summ += $array['summa'];}
        
        ?>
<p>Ваш доход равен в сумме <?php   echo $summ . " руб.";   ?></p>
      </div>
    </section>
    
    
    <?php  include 'footer.php';   ?>

    
  </body>

</html>