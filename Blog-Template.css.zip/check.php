<?php 

$email = filter_var(trim($_POST['email']), 
FILTER_SANITIZE_STRING); //фильтруем значение, удаляем всякий шлак, вдруг там скрипт ввели

$pass = filter_var(trim($_POST['pass']), 
FILTER_SANITIZE_STRING); //фильтруем значение, удаляем всякий шлак, вдруг там скрипт ввели



//проверки
if(mb_strlen($email) < 5 || mb_strlen($email) > 90)
{
    echo "Длина слишком маленькая или слишком большая (минимум 5, максимум 90)";
    exit();
} else if(mb_strlen($pass) < 5 || mb_strlen($pass) > 40)
{
    echo "Недопустимая длина пароля.";
    exit();
}
 
$pass = md5($pass."thdggdrgdgdrgd"); //а эта вещь шифрует пароль, он прекратится в непойми что, так еще и приклеются какие то символы, спокойно все норм


$host = 'localhost'; //вот переменные которые необходимы для выполнения подключения 
$db = 'f0636710_finanses_enter';
$user = 'f0636710_finanse_user';
$passwor = 'H0vv$t0$hack';

$mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем


//используем ф-ию query, она принимает любой запрос на языке БД mysql
$mysql->query("INSERT INTO `users` (`email`, `pass`) 
VALUES ('$email', '$pass')"); //вот эта команда говорит нам следующее "вставь в таблицу all_users поля (id, email, pass) значения ($email, $pass) || главное не забыть
//кавычки, и вы не поверите насколько они бл"ть важны (я мучался над ними 1 час)    

$mysql->query("CREATE TABLE `$email` ( `id` INT PRIMARY KEY AUTO_INCREMENT, `type` VARCHAR(100), `summa` REAL NOT NULL, `kategory` VARCHAR(30), `day_buyed` DATE NOT NULL )");
//создаем таблицу с данными о раходах для пользователя


//после того как все сделали обязательно закрываем подключение
$mysql->close();

header('Location: /Enter.php'); //говорим куда мы сразу перейдем

?>