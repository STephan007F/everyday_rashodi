<?php 

$sum =  filter_var(trim($_POST['sum']),
FILTER_SANITIZE_STRING);

$data = $_POST['data'];

if($sum == 0 || $data == '')
{
    echo "Не верные даннные!!!";
    exit();
}


$host = 'localhost'; //вот переменные которые необходимы для выполнения подключения
$db = 'f0636710_finanses_enter';
$user = 'f0636710_finanse_user';
$passwor = 'H0vv$t0$hack';

$mysql = new mysqli($host, $user, $passwor, $db); //ф-я mysqli принимает 4 параметра, их и пишем

if($mysql->connect_error)
{
    die("Connection failed: " . $mysql->connect_error);
}

$auth = $_COOKIE['user'];

$result = $mysql->query("INSERT INTO `$auth` (`type`, `summa`, `kategory`, `day_buyed`) 
VALUES ('earned', '$sum', null, '$data')");

if($result === FALSE)
{
  echo "плохо: " . $mysql->error; //пасхалОчка
  exit();
}

$mysql->close();

header("Location: index.php");


?>